package com.example.springWeb.Service;

import com.example.springWeb.Model.Product;
import com.example.springWeb.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class ProductService {

    @Autowired
    ProductRepository repo;

//    List<Product> products = new ArrayList<>(Arrays.asList(new Product(101,"Iphone",50000),
//            new Product(102,"Speaker", 5000),
//            new Product(103,"Sunscreen",2000)));

    public List<Product> getProducts(){
        return repo.findAll();
    }

    public Product getProductById(int productId) {
        return repo.findById(productId).orElse(new Product());
    }

    public void addProduct(Product prod) {
        repo.save(prod);
    }

    public void updateProduct(Product prod) {
        repo.save(prod);
    }

    public void delete(int productId) {
        repo.deleteById(productId);
    }
}
